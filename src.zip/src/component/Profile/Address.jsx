import React from 'react'
import { AddressCard } from '../Cart/AddressCard'

const Address = () => {
  return (
    <div>
      <AddressCard/>
    </div>
  )
}

export default Address